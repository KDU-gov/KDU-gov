/* 凯伦戴恩政务平台 · 核心逻辑冒烟测试（Node 环境，不依赖 DOM） */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const html = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error("FAIL: 未找到 <script> 块"); process.exit(1); }

/* ---- 最小化浏览器存根 ---- */
function makeLS(){
  const map = new Map();
  return {
    getItem: k => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: k => map.delete(k)
  };
}
const sandbox = {
  localStorage: makeLS(),
  sessionStorage: makeLS(),
  console, Math, Date, JSON, String, Number, Array, Object, parseInt, parseFloat,
  setTimeout, clearTimeout, setInterval, clearInterval,
  globalThis: null
};
sandbox.globalThis = sandbox;
sandbox.window = undefined;
sandbox.document = undefined;
vm.createContext(sandbox);

let ok = 0, fail = 0;
function assert(name, cond, detail){
  if (cond){ ok++; console.log("  PASS  " + name); }
  else { fail++; console.error("  FAIL  " + name + (detail ? "  → " + detail : "")); }
}

try {
  vm.runInContext(m[1], sandbox, { filename: "app.js" });
} catch (e) {
  console.error("FAIL: 脚本执行异常", e);
  process.exit(1);
}
const K = sandbox.KDN_TEST;

/* ---- 0. 初始化存储 ---- */
K.loadStore();

/* ---- 1. 世界数据 ---- */
assert("7 个加盟共和国 B-H + 直辖市 A", K.REPUBLICS.length === 8 && K.REPUBLICS[0].code === "A" && K.REPUBLICS.slice(1).length === 7);
const totalStates = K.REPUBLICS.slice(1).reduce((a, r) => a + r.states.length, 0);
assert("37 个州（不含直辖市）", totalStates === 37, "实际 " + totalStates);
assert("账号 000001/000002/000003", K.ACCOUNTS.length === 3 && K.ACCOUNTS[0].id === "000001");

/* ---- 2. 每日生成 ---- */
const D = "2026-09-13";
const day = K.generateDay(D);
assert("每日事件 15 件（3 干部×5）", day.events.length === 15, "实际 " + day.events.length);
assert("每日新闻 10 条", day.news.length === 10, "实际 " + day.news.length);

/* ---- 3. 文件编号规律 ---- */
const re = /^KDU[A-H][HZ]-\d{5}$/;
let badNo = day.events.filter(e => !re.test(e.fileNo));
assert("全部文件编号符合 KDU?[HZ]-XXXXX", badNo.length === 0, badNo.map(e => e.fileNo).join(","));
let centralBad = day.events.filter(e => e.isCentral && !e.fileNo.startsWith("KDUA"));
assert("中央文件一律 KDUA 开头", centralBad.length === 0);
let typeBad = day.events.filter(e => { const suf=e.fileNo.split("-")[0].slice(-1); return e.type==="approval" ? suf!=="Z" : suf!=="H"; });
assert("批复类=Z 后缀、汇报类=H 后缀", typeBad.length === 0, typeBad.map(e => e.fileNo + "/" + e.type).join(","));
const nos = new Set(day.events.map(e => e.fileNo));
assert("当日文件编号唯一", nos.size === day.events.length);
const localNo = day.events.filter(e => !e.isCentral).every(e => /^KDU[B-H][HZ]-\d{5}$/.test(e.fileNo));
assert("地方文件编号含共和国代码 B-H", localNo);

/* ---- 4. 稳定重生成 ---- */
const day2 = K.generateDay(D);
assert("同日重生成事件一致（缓存）", JSON.stringify(day.events) === JSON.stringify(day2.events));

/* ---- 5. 7 日窗口与历史播种 ---- */
K.ensureWindow();
const t = K.todayStr();
let days7 = 0;
for (let i = 0; i <= 6; i++) days7 += K.getStore().events[K.dateAdd(t, -i)] ? 1 : 0;
assert("近 7 日数据齐备", days7 === 7, "实际 " + days7);
K.seedHistory();
assert("历史已播种", K.getStore().seeded === true);
const decCount = Object.keys(K.getStore().decisions).length;
assert("已生成批复记录（>0）", decCount > 0, "实际 " + decCount);

/* ---- 6. 各干部待批复/已批复 ---- */
const pP = K.myPending("P"), pN = K.myPending("N"), pG = K.myPending("G");
assert("总理待批复>0", pG.length > 0, "实际 " + pG.length);
const cP = K.chairmanPending();
const delibItems = cP.filter(x => x.origin);
assert("主席待批复含他人提请待议件（有来历）", delibItems.length > 0, "实际 " + delibItems.length);
assert("待议件带来历信息", delibItems.every(x => x.origin.byName && x.origin.at));
const dN = K.myDone("N");
assert("国安委已批复>0", dN.length > 0, "实际 " + dN.length);
const ch = K.charterItems();
assert("章程记录>0", ch.length > 0, "实际 " + ch.length);
assert("章程仅含其他干部批复", ch.every(x => x.others.length > 0));

/* ---- 7. 实时互通：待议 → 主席栏；批复 → 章程 ---- */
const G_pending0 = K.myPending("G").length;
const target = K.myPending("G").find(x => x.ev.type === "approval" && !x.note);
assert("总理有待批复的批复类事件", !!target, "无合适测试对象");
const fno = target.ev.fileNo;
K.recordDecision(fno, "deliberating", "事关重大，提请主席批示。", "G", "伊尔·冯·卡连基耶夫", "国务院总理");
const inChair = K.chairmanPending().find(x => x.ev.fileNo === fno);
assert("待议后事件直接出现在主席待批复栏", !!inChair);
assert("主席栏标明来历", inChair && inChair.origin && inChair.origin.byName === "伊尔·冯·卡连基耶夫");
const stillG = K.myPending("G").find(x => x.ev.fileNo === fno);
assert("待议后从总理待批复栏移除", !stillG);
K.recordDecision(fno, "approved", "同意。", "P", "德拉戈米尔·高尔格维奇", "主席");
const inCharter = K.charterItems().find(x => x.ev.fileNo === fno);
assert("主席批复后该事件在章程留痕", !!inCharter);
const notInChair = K.chairmanPending().find(x => x.ev.fileNo === fno);
assert("主席批复后从主席待批复栏移出", !notInChair);

/* ---- 8. 主席退回 → 回到原干部待批复 ---- */
const f2 = K.myPending("N").find(x => x.ev.type === "approval");
assert("国安委有待批复批复类事件", !!f2);
const fno2 = f2.ev.fileNo;
K.recordDecision(fno2, "approved", "同意。", "N", "雷利亚诺·拉米雷斯·弗洛雷斯", "国家安全委员会主席");
K.recordDecision(fno2, "returned", "请重新论证。", "P", "德拉戈米尔·高尔格维奇", "主席");
const backN = K.myPending("N").find(x => x.ev.fileNo === fno2);
assert("主席退回后事件回到原干部待批复栏", !!backN);
assert("退回件带主席退回说明", backN && /主席退回/.test(backN.note));

/* ---- 9. 批复类型选项约束 ---- */
const reportEv = K.myPending("G").find(x => x.ev.type === "report");
if (reportEv) {
  K.recordDecision(reportEv.ev.fileNo, "read", "已阅", "G", "伊尔·冯·卡连基耶夫", "国务院总理");
  const doneG = K.myDone("G").find(x => x.ev.fileNo === reportEv.ev.fileNo);
  assert("仅汇报事件可批复为已阅并移入已批复", !!doneG && doneG.decision.status === "read");
}

/* ---- 10. 生成器跨日变化 ---- */
const D2 = "2026-09-14";
const dayB = K.generateDay(D2);
assert("次日生成新事件且编号不同", dayB.events[0].fileNo !== day.events[0].fileNo);
assert("次日文件编号仍合规", dayB.events.every(e => re.test(e.fileNo)));

console.log("\n结果：" + ok + " 通过 / " + fail + " 失败");
process.exit(fail ? 1 : 0);
