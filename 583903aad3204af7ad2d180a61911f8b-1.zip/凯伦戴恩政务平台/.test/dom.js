/* 凯伦戴恩政务平台 · DOM 渲染冒烟测试（jsdom 无头环境） */
const fs = require("fs");
const path = require("path");
const { JSDOM, VirtualConsole } = require("jsdom");

const html = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", e => errors.push("jsdomError: " + e.message));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(html, {
  url: "https://kdn.example.gov/",
  runScripts: "dangerously",
  pretendToBeVisual: true,
  virtualConsole: vc,
  beforeParse(window) {
    window.scrollTo = () => {};
    if (!window.URL.createObjectURL) {
      window.URL.createObjectURL = () => "blob:mock";
      window.URL.revokeObjectURL = () => {};
    }
    /* jsdom 不支持下载导航，拦截 a.click 记录 download 文件名 */
    window.__dl = [];
    const origClick = window.HTMLAnchorElement.prototype.click;
    window.HTMLAnchorElement.prototype.click = function(){
      if (this.download) { window.__dl.push(this.download); return; }
      origClick.call(this);
    };
  }
});

const { window } = dom;
const { document } = window;
let ok = 0, fail = 0;
function assert(name, cond, detail){
  if (cond){ ok++; console.log("  PASS  " + name); }
  else { fail++; console.error("  FAIL  " + name + (detail ? "  → " + detail : "")); }
}
function $(sel){ return document.querySelector(sel); }
function $$(sel){ return Array.from(document.querySelectorAll(sel)); }
function type(el2, v){ el2.value = v; el2.dispatchEvent(new window.Event("input", {bubbles:true})); }
function click(el2){ el2.dispatchEvent(new window.MouseEvent("click", {bubbles:true, cancelable:true})); }
function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

(async () => {
  await sleep(100);

  /* 1. 登录页 */
  assert("登录页可见", !$("#view-login").classList.contains("hidden"));
  const countryLine = $("#view-login .lg-country");
  assert("国名单行不换行", window.getComputedStyle(countryLine).whiteSpace === "nowrap");
  assert("登录页无演示账号引导", !document.body.textContent.includes("演示账号"));

  /* 2. 错误密码 */
  type($("#lg-id"), "000001"); type($("#lg-pwd"), "wrong");
  click($("#lg-go"));
  await sleep(30);
  assert("错误密码提示", $("#lg-err").textContent.includes("有误"));

  /* 3. 总理登录 000003 */
  type($("#lg-id"), "000003");
  type($("#lg-pwd"), "KDN-0003");
  click($("#lg-go"));
  await sleep(60);
  assert("主框架可见", !$("#app-shell").classList.contains("hidden"));
  assert("侧栏显示用户名", $("#tb-uname").textContent.includes("伊尔·冯·卡连基耶夫"));
  const navs = $$("#sb-nav .sb-item").map(n => n.textContent.trim());
  assert("普通干部三个栏目", navs.length === 3 && navs.join("|").includes("待批复事件") && navs.join("|").includes("已批复事件") && navs.join("|").includes("新闻"), navs.join(","));
  assert("普通干部无章程栏目", !navs.some(n => n.includes("章程")));
  const pendingCount = $$("#main .ev").length;
  assert("待批复列表有事件", pendingCount > 0, "实际 " + pendingCount);

  /* 4. 态势图 */
  click($("#btn-overview"));
  await sleep(40);
  assert("态势图渲染", $("#main .page-title").textContent.includes("政务态势图"));
  assert("态势图含SVG图表", $$("#main svg").length >= 4, "实际 " + $$("#main svg").length);
  assert("态势图含KPI", $$("#main .kpi").length >= 4);

  /* 5. 新闻 */
  click($$("#sb-nav .sb-item").find(n => n.textContent.includes("新闻")));
  await sleep(40);
  assert("新闻10条", $$("#main .news").length === 10, "实际 " + $$("#main .news").length);

  /* 6. 事件详情 + 红头文件 */
  click($$("#sb-nav .sb-item").find(n => n.textContent.includes("待批复")));
  await sleep(40);
  const firstEv = $$("#main .ev")[0];
  const fno = firstEv.getAttribute("data-open");
  click(firstEv);
  await sleep(40);
  assert("详情模态打开", !!$("#modal-root .modal"));
  assert("详情含文号", $("#modal-root").textContent.includes(fno));
  click($("#modal-root [data-doc]"));
  await sleep(40);
  assert("红头文件模态", $("#modal-root").textContent.includes("凯伦戴恩社会主义共和国联盟"));
  assert("红头文件含文号行", $("#modal-root").textContent.includes("凯政〔"));
  click($("#modal-root [data-dl]"));
  await sleep(40);
  assert("下载触发（生成 .html 红头文件）", window.__dl.length === 1 && window.__dl[0] === fno + ".html", JSON.stringify(window.__dl));
  click($("#modal-root [data-x]"));
  await sleep(30);

  /* 7. 批复流转：总理→待议→主席栏 */
  const pendApproval = $$("#main .ev").find(c => c.querySelector(".b-zt"));
  assert("有待批复的需批准事件", !!pendApproval);
  const fno2 = pendApproval.getAttribute("data-open");
  click(pendApproval);
  await sleep(30);
  click($("#modal-root [data-decide]"));
  await sleep(30);
  const optLabels = $$("#modal-root [data-opt]").map(b => b.textContent.trim());
  assert("批复三选项（批准/否决/待议）", optLabels.join("|") === "批准|否决|待议", optLabels.join(","));
  click($$("#modal-root [data-opt]").find(b => b.textContent.trim() === "待议"));
  await sleep(50);
  assert("待议后从待批复移除", !$$("#main .ev").some(c => c.getAttribute("data-open") === fno2));

  /* 8. 主席登录看待议件 */
  click($("#btn-logout"));
  await sleep(30);
  type($("#lg-id"), "000001"); type($("#lg-pwd"), "KDN-0001");
  click($("#lg-go"));
  await sleep(60);
  const navsP = $$("#sb-nav .sb-item").map(n => n.textContent.trim());
  assert("主席四个栏目", navsP.length === 4 && navsP.some(n => n.includes("国家近期章程")), navsP.join(","));
  const originCards = $$("#main .ev-origin");
  const foundOrigin = originCards.some(o => o.textContent.includes("来历") && o.textContent.includes("伊尔·冯·卡连基耶夫"));
  assert("主席待批复栏直接出现待议件并标明来历", foundOrigin);
  assert("待议件无需手动输入编号即可见", originCards.length > 0);

  /* 9. 主席处理待议件 */
  const delibCard = $$("#main .ev").find(c => c.querySelector(".ev-origin"));
  click(delibCard);
  await sleep(30);
  click($("#modal-root [data-decide]"));
  await sleep(30);
  const pOpts = $$("#modal-root [data-opt]").map(b => b.textContent.trim());
  assert("主席批复选项（批准/否决）", pOpts.join("|") === "批准|否决", pOpts.join(","));
  click($$("#modal-root [data-opt]").find(b => b.textContent.trim() === "批准"));
  await sleep(50);

  /* 10. 章程 */
  click($$("#sb-nav .sb-item").find(n => n.textContent.includes("章程")));
  await sleep(40);
  assert("章程渲染", $("#main .page-title").textContent.includes("国家近期章程"));
  const charterItems = $$("#main .charter-item").length;
  assert("章程有条目", charterItems > 0, "实际 " + charterItems);
  const chBtn = $("#main [data-charter]");
  assert("章程有更改按钮", !!chBtn);
  click(chBtn);
  await sleep(30);
  const chOpts = $$("#modal-root [data-opt]").map(b => b.textContent.trim());
  assert("更改含退回原部门", chOpts.includes("退回原部门"), chOpts.join(","));
  click($("#modal-root [data-x]"));
  await sleep(20);

  /* 11. 已批复栏目 */
  click($$("#sb-nav .sb-item").find(n => n.textContent.includes("已批复")));
  await sleep(40);
  assert("主席已批复有内容", $$("#main .ev").length > 0);

  /* 12. 无运行时错误 */
  assert("全程无 JS 报错", errors.length === 0, errors.slice(0,5).join(" || "));

  console.log("\n结果：" + ok + " 通过 / " + fail + " 失败");
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("测试崩溃:", e); process.exit(1); });
